﻿using System.Threading.Tasks;
using System.Windows.Forms;
using System;

namespace Caro
{
    public partial class Form_game : Form
    {
        #region Properties
        ChessBoardManager ChessBoard;
        Form_chatbox chatForm = null; // Biến lưu trữ Form Chat
        #endregion

        public Form_game()
        {
            InitializeComponent();

            this.StartPosition = FormStartPosition.Manual;
            this.Location = new System.Drawing.Point(65, 80); // Đặt tọa độ (X=100, Y=100)

            ChessBoard = new ChessBoardManager(pnlChessBoard, txtPlayerName, pcbMark);
            ChessBoard.DrawChessBoard();

            this.Load += box_chat_Load; // Gán sự kiện Load
        }

        private async void box_chat_Load(object sender, EventArgs e)
        {
            await Task.Delay(250); // Chờ 250ms trước khi mở form chat

            if (chatForm == null || chatForm.IsDisposed) // Đảm bảo không bị đóng ngay lập tức
            {
                chatForm = new Form_chatbox();
                chatForm.Show();
            }
        }

        private void chat_button_Click(object sender, EventArgs e)
        {
            if (chatForm == null || chatForm.IsDisposed) // Kiểm tra nếu form chat chưa mở hoặc đã đóng
            {
                chatForm = new Form_chatbox();
                chatForm.Show();
            }
            else
            {
                // chatForm.Focus(); // Nếu form chat đã mở, đưa nó lên trước
                chatForm.Close(); // Nếu form đang mở, đóng nó
                chatForm = null;
            }
        }
    }
}
