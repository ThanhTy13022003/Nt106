﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//dùng để lưu các hằng số
namespace Caro
{
    class cons
    {
        public static int CHESS_WIDTH = 30; // chiều cao 1 quân cờ
        public static int CHESS_HEIGHT = 30;// chiều rộng 1 quân cờ

        public static int CHESS_BOARD_WIDTH = 15;// chiều cao bàn cờ
        public static int CHESS_BOARD_HEIGHT = 15;// chiều rộng bàn cờ
    }
}
